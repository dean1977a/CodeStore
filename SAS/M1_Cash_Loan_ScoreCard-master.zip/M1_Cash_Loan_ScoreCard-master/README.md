

# 1.斜体和粗体 <br>
_Italics_ <br>
**Bold** <br>
_**both italics and bold**_ <br>
**_on the outside_** <br>


# 2.标题 <br>
# Header one <br>
## Header two  <br>
### Header three <br>
#### Header four  <br>
##### Header five  <br>
###### Header six  <br>

# 3.链接 <br>
a.inline link <br>
Search for it.[Visit Baidu](http://www.baidu.com) <br>
Again.[You're **really, really** going to want to see this.](http://www.dailykitten.com)   <br>
###The Latest News from the [BBC](www.bbc.com/news)   <br>
b.regference link 适用于该链接在文中出现了多次，这个markdown语法在github中居然实现不了 <br>
Here's [a link to something else][another place].
 Here's [yet another link][another-link].
     And now back to [the first link][another place].

     [another place]: http://www.github.com
     [another-link]: http://www.google.com
     
# 4.添加图片 <br>

    

